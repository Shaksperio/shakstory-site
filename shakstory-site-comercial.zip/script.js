(() => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#main-nav');
  if (toggle && nav) {
    const close = () => { nav.classList.remove('open'); toggle.setAttribute('aria-expanded','false'); toggle.setAttribute('aria-label','Abrir menu'); };
    toggle.addEventListener('click', () => { const open = nav.classList.toggle('open'); toggle.setAttribute('aria-expanded',String(open)); toggle.setAttribute('aria-label',open ? 'Fechar menu':'Abrir menu'); });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click',close));
    window.addEventListener('keydown',e => { if(e.key === 'Escape') close(); });
  }
  const year = document.querySelector('#year');
  if(year) year.textContent = String(new Date().getFullYear());
})();
